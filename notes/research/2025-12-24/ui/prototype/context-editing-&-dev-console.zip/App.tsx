
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Play, 
  Pause, 
  FastForward, 
  Terminal as TerminalIcon, 
  Settings, 
  Camera, 
  Edit3, 
  History, 
  Box, 
  Layers, 
  Zap,
  Save,
  Trash2,
  ChevronRight,
  RefreshCw,
  Search,
  Clock,
  Maximize2
} from 'lucide-react';
import { DriverState, Frame, LogEntry, Snapshot, TimelineMarker } from './types';
import { describeFrame, editFrame } from './services/geminiService';

// --- Helper Components ---

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 text-sm font-medium transition-colors ${active ? 'bg-zinc-800 text-white' : 'text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-200'}`}
  >
    {icon}
    <span>{label}</span>
  </button>
);

const IconButton: React.FC<{ icon: React.ReactNode; onClick: () => void; disabled?: boolean; title?: string; color?: string }> = ({ icon, onClick, disabled, title, color }) => (
  <button 
    title={title}
    onClick={onClick} 
    disabled={disabled}
    className={`p-2 rounded-md transition-all ${disabled ? 'opacity-30 cursor-not-allowed' : `hover:bg-zinc-700 active:scale-95 ${color || 'text-zinc-300'}`}`}
  >
    {icon}
  </button>
);

// --- Main Application ---

export default function App() {
  const [state, setState] = useState<DriverState>(DriverState.IDLE);
  const [prompt, setPrompt] = useState('a red ball bouncing on grass, sunny day');
  const [frames, setFrames] = useState<Frame[]>([]);
  const [markers, setMarkers] = useState<TimelineMarker[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [snapshots, setSnapshots] = useState<Snapshot[]>([]);
  const [activeTab, setActiveTab] = useState<'console' | 'snapshots' | 'settings'>('console');
  const [selectedFrameId, setSelectedFrameId] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editInstruction, setEditInstruction] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const logsEndRef = useRef<HTMLDivElement>(null);
  const generationInterval = useRef<number | null>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  // Initialize with some fake frames
  useEffect(() => {
    const initialFrames: Frame[] = Array.from({ length: 15 }).map((_, i) => ({
      id: `frame-${i}`,
      url: `https://picsum.photos/seed/${i + 50}/640/360`,
      timestamp: Date.now() - (14 - i) * 1000,
      isAnchor: i === 0
    }));
    setFrames(initialFrames);
    addLog('info', 'Temporal pipeline stabilized. KV context active.');
  }, []);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  const addLog = (type: LogEntry['type'], message: string) => {
    setLogs(prev => [...prev, {
      id: Math.random().toString(36).substr(2, 9),
      type,
      message,
      timestamp: new Date()
    }]);
  };

  const handleStep = useCallback(() => {
    const newId = `frame-${Date.now()}`;
    const newFrame: Frame = {
      id: newId,
      url: `https://picsum.photos/seed/${Math.random()}/640/360`,
      timestamp: Date.now(),
      isAnchor: false
    };

    setFrames(prev => {
      const updated = [...prev, newFrame];
      // Keep a longer history for the timeline
      if (updated.length > 50) return updated.slice(1);
      return updated;
    });

    addLog('command', `Latent step ${newId.substring(6, 12)} | Inference: 312ms`);
  }, []);

  useEffect(() => {
    if (state === DriverState.RUNNING) {
      generationInterval.current = window.setInterval(handleStep, 1000);
    } else {
      if (generationInterval.current) clearInterval(generationInterval.current as number);
    }
    return () => { if (generationInterval.current) clearInterval(generationInterval.current as number); };
  }, [state, handleStep]);

  const toggleRun = () => {
    if (state === DriverState.RUNNING) {
      setState(DriverState.PAUSED);
      addLog('info', 'Directing suspended.');
    } else {
      setState(DriverState.RUNNING);
      addLog('info', 'Real-time inference resumed.');
    }
  };

  const handleDescribe = async (frame: Frame) => {
    setIsAnalyzing(true);
    addLog('info', `Analyzing frame context: ${frame.id.slice(-6)}`);
    try {
      const description = await describeFrame(frame.url);
      setFrames(prev => prev.map(f => f.id === frame.id ? { ...f, description } : f));
      
      const newMarker: TimelineMarker = {
        id: `vlm-${Date.now()}`,
        frameId: frame.id,
        type: 'vlm',
        label: 'VLM Analysis',
        color: 'bg-amber-500'
      };
      setMarkers(prev => [...prev, newMarker]);
      addLog('success', `VLM output integrated into context.`);
    } catch (err) {
      addLog('error', `VLM Analysis failed: ${err}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleEditAnchor = async () => {
    if (!editInstruction) return;
    setIsEditing(true);
    const anchor = frames.find(f => f.isAnchor) || frames[0];
    addLog('info', `Injecting semantic edit into Anchor ${anchor.id.slice(-6)}`);
    
    try {
      const editedUrl = await editFrame(anchor.url, editInstruction);
      setFrames(prev => prev.map(f => f.id === anchor.id ? { ...f, url: editedUrl } : f));
      
      const newMarker: TimelineMarker = {
        id: `edit-${Date.now()}`,
        frameId: anchor.id,
        type: 'edit',
        label: editInstruction,
        color: 'bg-indigo-500'
      };
      setMarkers(prev => [...prev, newMarker]);
      addLog('success', 'Anchor frame modified. KV cache will recompute on next step.');
      setEditInstruction('');
    } catch (err) {
      addLog('error', `Edit injection failed: ${err}`);
    } finally {
      setIsEditing(false);
    }
  };

  const selectedFrame = frames.find(f => f.id === selectedFrameId) || frames[frames.length - 1];

  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 font-sans select-none overflow-hidden">
      
      {/* Sidebar Nav */}
      <aside className="w-64 border-r border-zinc-800 flex flex-col bg-zinc-900/50">
        <div className="p-6 flex items-center gap-3">
          <div className="p-2 bg-indigo-600 rounded-lg shadow-lg shadow-indigo-900/20">
            <Box size={20} className="text-white" />
          </div>
          <h1 className="font-bold text-lg tracking-tight">Scope Dev</h1>
        </div>

        <nav className="flex-1 overflow-y-auto">
          <div className="px-4 py-2 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Pipeline</div>
          <SidebarItem icon={<TerminalIcon size={18} />} label="Dev Console" active={activeTab === 'console'} onClick={() => setActiveTab('console')} />
          <SidebarItem icon={<History size={18} />} label="Context Snaps" active={activeTab === 'snapshots'} onClick={() => setActiveTab('snapshots')} />
          <SidebarItem icon={<Clock size={18} />} label="History" />
          <SidebarItem icon={<Settings size={18} />} label="Parameters" />
          
          <div className="px-4 mt-8 py-2 text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Live Engine</div>
          <div className="px-6 py-2 space-y-4">
            <div>
               <div className="flex items-center gap-2 mb-1">
                <div className={`w-2 h-2 rounded-full ${state === DriverState.RUNNING ? 'bg-green-500 animate-pulse' : 'bg-zinc-600'}`} />
                <span className="text-xs font-mono text-zinc-300">{state}</span>
              </div>
              <div className="text-[10px] text-zinc-500 font-mono uppercase">Engine Status</div>
            </div>
            
            <div className="h-px bg-zinc-800" />
            
            <div className="space-y-2">
              <div className="flex justify-between text-[10px] text-zinc-400">
                <span>VRAM Pressure</span>
                <span>72%</span>
              </div>
              <div className="w-full h-1 bg-zinc-800 rounded-full overflow-hidden">
                <div className="h-full bg-indigo-500 w-[72%]" />
              </div>
            </div>
          </div>
        </nav>

        <div className="p-4 border-t border-zinc-800">
           <div className="bg-zinc-800/30 rounded-lg p-3 text-[10px] text-zinc-500 font-mono">
              Cluster: us-west-1<br/>
              Model: gemini-3-pro-v1<br/>
              Precision: FP16
           </div>
        </div>
      </aside>

      {/* Main Workspace */}
      <main className="flex-1 flex flex-col min-w-0">
        
        {/* Top Action Bar */}
        <header className="h-16 border-b border-zinc-800 flex items-center justify-between px-6 bg-zinc-950/50 backdrop-blur-xl z-20">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <IconButton 
                icon={state === DriverState.RUNNING ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" />} 
                onClick={toggleRun}
                color={state === DriverState.RUNNING ? "text-amber-500" : "text-emerald-500"}
              />
              <IconButton 
                icon={<FastForward size={20} />} 
                onClick={handleStep}
                disabled={state === DriverState.RUNNING}
                title="Single Iteration"
              />
            </div>
            <div className="h-6 w-px bg-zinc-800" />
            <div className="flex items-center gap-3 bg-zinc-900/50 px-4 py-1.5 rounded-full border border-zinc-800 shadow-inner group transition-all focus-within:border-indigo-500/50">
              <Layers size={14} className="text-zinc-500 group-focus-within:text-indigo-400 transition-colors" />
              <input 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="bg-transparent text-xs outline-none w-80 text-zinc-300 placeholder-zinc-600 font-medium"
                placeholder="Direct latent space..."
              />
            </div>
          </div>

          <div className="flex items-center gap-3">
             <div className="text-[10px] font-mono text-zinc-500 bg-zinc-900 px-2 py-1 rounded">
                BUF: {frames.length}/50
             </div>
            <button 
              onClick={() => addLog('info', 'Snapshot saved to context registry.')}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition-all active:scale-95 shadow-lg shadow-indigo-900/20"
            >
              <Save size={14} />
              Snapshot
            </button>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 flex flex-col min-h-0 bg-zinc-950">
          
          {/* Main Stage */}
          <section className="flex-1 p-6 flex flex-col gap-6 overflow-hidden">
            
            {/* Viewport and Secondary Panels */}
            <div className="flex-1 grid grid-cols-12 gap-6 min-h-0">
              
              {/* Left: Viewport */}
              <div className="col-span-8 flex flex-col gap-4 min-h-0">
                <div className="flex-1 relative bg-black rounded-2xl overflow-hidden border border-zinc-800 shadow-2xl group">
                  {selectedFrame && (
                    <img 
                      src={selectedFrame.url} 
                      className="w-full h-full object-contain"
                      alt="Current Frame"
                    />
                  )}
                  
                  {/* Overlay Info */}
                  <div className="absolute top-6 left-6 flex flex-col gap-2">
                    {selectedFrame?.isAnchor && (
                      <div className="bg-indigo-600/90 backdrop-blur-xl text-[10px] font-bold px-3 py-1 rounded-full text-white flex items-center gap-2 border border-indigo-400/30">
                        <Zap size={10} fill="currentColor" /> ACTIVE ANCHOR
                      </div>
                    )}
                    <div className="bg-zinc-900/80 backdrop-blur-md text-[10px] font-mono px-3 py-1 rounded-full text-zinc-400 border border-zinc-700/50">
                      FRAME_HEX: {selectedFrame?.id.slice(-6).toUpperCase()}
                    </div>
                  </div>

                  {/* VLM Insight Overlay */}
                  {selectedFrame?.description && (
                    <div className="absolute top-6 right-6 max-w-xs bg-zinc-900/90 backdrop-blur-xl p-4 rounded-xl border border-zinc-700/50 shadow-2xl animate-in fade-in slide-in-from-right-4 duration-300">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest flex items-center gap-1">
                          <Search size={10} /> Contextual Analysis
                        </div>
                        <IconButton icon={<Maximize2 size={12} />} onClick={() => {}} />
                      </div>
                      <p className="text-xs text-zinc-300 leading-relaxed font-mono">
                        {selectedFrame.description}
                      </p>
                    </div>
                  )}

                  <div className="absolute bottom-6 right-6 opacity-0 group-hover:opacity-100 transition-all transform translate-y-2 group-hover:translate-y-0">
                    <button 
                      onClick={() => handleDescribe(selectedFrame)} 
                      disabled={isAnalyzing}
                      className="flex items-center gap-2 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white px-4 py-2 rounded-full border border-white/20 text-xs font-bold transition-all"
                    >
                      {isAnalyzing ? <RefreshCw size={14} className="animate-spin" /> : <Search size={14} />}
                      Analyze with VLM
                    </button>
                  </div>
                </div>
              </div>

              {/* Right: Controls & Context Edit */}
              <div className="col-span-4 flex flex-col gap-4 overflow-y-auto pr-2">
                
                {/* Context Editing Panel */}
                <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6 backdrop-blur-sm">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-500/10 rounded-lg">
                        <Edit3 size={18} className="text-indigo-400" />
                      </div>
                      <h3 className="text-sm font-bold text-zinc-200">Context Injection</h3>
                    </div>
                    <div className="text-[10px] font-mono text-zinc-500">OP_CODE: 0x2A</div>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between items-end mb-3">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Target Anchor</label>
                        <span className="text-[10px] text-zinc-600 font-mono">ID: {frames[0]?.id.slice(-6)}</span>
                      </div>
                      <div className="p-1 bg-zinc-950 rounded-xl border border-zinc-800 shadow-inner group overflow-hidden">
                        <div className="relative aspect-video rounded-lg overflow-hidden border border-zinc-800/50">
                          <img src={frames.find(f => f.isAnchor)?.url || frames[0]?.url} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-700" alt="" />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                             <div className="text-[10px] font-bold text-white uppercase flex items-center gap-1">
                                <Zap size={10} className="text-indigo-400" /> Sequence Start
                             </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Semantic Delta</label>
                        <button className="text-[10px] text-indigo-400 hover:text-indigo-300 font-bold">TEMPLATES</button>
                      </div>
                      <textarea 
                        value={editInstruction}
                        onChange={(e) => setEditInstruction(e.target.value)}
                        placeholder="Define spatial or material changes to inject..."
                        className="w-full h-32 bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-xs text-zinc-300 resize-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/20 outline-none transition-all placeholder-zinc-700 font-mono"
                      />
                      <button 
                        onClick={handleEditAnchor}
                        disabled={isEditing || !editInstruction}
                        className="w-full py-3 bg-zinc-100 hover:bg-white text-zinc-950 rounded-xl text-xs font-black transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-xl active:scale-95"
                      >
                        {isEditing ? <RefreshCw className="animate-spin" size={16} /> : <Camera size={16} />}
                        EXECUTE RETROACTIVE EDIT
                      </button>
                    </div>

                    <div className="bg-amber-500/10 border border-amber-500/20 rounded-lg p-3">
                      <p className="text-[10px] text-amber-500/80 leading-relaxed font-medium">
                        Warning: Modifying anchor frames triggers a global KV cache invalidation. Next 3 chunks will have high latency.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Status/Metics */}
                <div className="bg-zinc-900/30 border border-zinc-800 rounded-2xl p-6">
                   <div className="flex items-center gap-2 mb-6">
                    <Zap size={18} className="text-amber-400" />
                    <h3 className="text-sm font-bold text-zinc-200 uppercase tracking-tight">Engine Metrics</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {[
                      { label: 'Latency', val: '242ms', sub: 'P99' },
                      { label: 'VRAM', val: '18.4GB', sub: '81%' },
                      { label: 'Throughput', val: '12FPS', sub: 'Latent' },
                      { label: 'Entropy', val: '0.041', sub: 'Drift' },
                    ].map(m => (
                      <div key={m.label} className="bg-zinc-950 p-4 rounded-xl border border-zinc-800/50 shadow-inner">
                        <div className="text-[9px] text-zinc-500 font-bold uppercase mb-1">{m.label}</div>
                        <div className="flex items-baseline gap-2">
                          <div className="text-lg font-mono text-zinc-200 font-bold">{m.val}</div>
                          <div className="text-[9px] text-zinc-600 font-mono">{m.sub}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* MASTER TIMELINE COMPONENT */}
            <div className="h-40 bg-zinc-900/50 border border-zinc-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl">
              <div className="flex items-center justify-between px-6 h-10 border-b border-zinc-800/50 bg-zinc-900/30">
                 <div className="flex items-center gap-4">
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest flex items-center gap-2">
                      <Clock size={12} className="text-indigo-400" /> Temporal Context Registry
                    </span>
                    <div className="h-4 w-px bg-zinc-800" />
                    <div className="flex gap-4">
                       <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full bg-indigo-500" />
                          <span className="text-[9px] text-zinc-500 font-bold">EDIT INJECTION</span>
                       </div>
                       <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full bg-amber-500" />
                          <span className="text-[9px] text-zinc-500 font-bold">VLM ANALYSIS</span>
                       </div>
                    </div>
                 </div>
                 <div className="text-[10px] font-mono text-zinc-500">
                    ZOOM: 1.0X
                 </div>
              </div>
              
              <div className="flex-1 relative overflow-x-auto overflow-y-hidden" ref={timelineRef}>
                {/* Timeline Tracks */}
                <div className="min-w-full inline-flex flex-col p-4 gap-2 h-full">
                  
                  {/* Track 1: Metadata Markers */}
                  <div className="h-6 relative">
                     {markers.map(m => {
                        const frameIdx = frames.findIndex(f => f.id === m.frameId);
                        if (frameIdx === -1) return null;
                        return (
                          <div 
                            key={m.id}
                            className={`absolute top-0 w-3 h-3 rounded-full ${m.color} border-2 border-zinc-900 -ml-1.5 cursor-help transition-transform hover:scale-150 z-10 shadow-lg`}
                            style={{ left: `${(frameIdx * 100) + 50}px` }}
                            title={m.label}
                          />
                        );
                     })}
                     <div className="absolute inset-x-0 top-1.5 h-px bg-zinc-800" />
                  </div>

                  {/* Track 2: Frames */}
                  <div className="flex gap-2">
                    {frames.map((frame, idx) => (
                      <div key={frame.id} className="relative flex-shrink-0">
                        <button
                          onClick={() => setSelectedFrameId(frame.id)}
                          className={`relative w-24 aspect-video rounded-lg overflow-hidden border-2 transition-all duration-300 shadow-xl ${
                            selectedFrameId === frame.id ? 'border-indigo-500 scale-105 z-10 ring-4 ring-indigo-500/10' : 'border-zinc-800 hover:border-zinc-600'
                          }`}
                        >
                          <img src={frame.url} className="w-full h-full object-cover" alt="" />
                          
                          {/* Anchor Overlay */}
                          {frame.isAnchor && (
                             <div className="absolute inset-0 bg-indigo-500/10 flex items-center justify-center">
                               <Zap size={16} className="text-white drop-shadow-md" />
                             </div>
                          )}
                          
                          {/* Sequence Label */}
                          <div className="absolute bottom-1 right-1 bg-black/60 backdrop-blur-sm px-1.5 rounded text-[8px] font-mono text-zinc-400 border border-white/5">
                            {idx.toString().padStart(3, '0')}
                          </div>
                        </button>
                      </div>
                    ))}
                    
                    {/* Active Generation Window (Shadow) */}
                    <div className="flex-shrink-0 w-48 border-2 border-dashed border-zinc-800 rounded-xl flex items-center justify-center bg-zinc-900/20">
                        <div className="flex flex-col items-center gap-2">
                           <RefreshCw size={18} className={`text-zinc-700 ${state === DriverState.RUNNING ? 'animate-spin' : ''}`} />
                           <span className="text-[10px] text-zinc-700 font-bold uppercase tracking-tighter">Inference...</span>
                        </div>
                    </div>
                  </div>

                  {/* Track 3: Context Window Highlight */}
                  <div className="h-2 relative mt-1 px-1">
                      <div className="absolute bottom-0 right-0 h-1 rounded-full bg-emerald-500/30 w-[1200px]" />
                      <div className="absolute bottom-0 left-0 h-1 rounded-full bg-indigo-500/50 w-24" />
                  </div>
                </div>

                {/* Playhead Overlay */}
                <div 
                  className="absolute top-0 bottom-0 w-px bg-rose-500 z-20 pointer-events-none transition-all duration-300 shadow-[0_0_10px_rgba(244,63,94,0.5)]" 
                  style={{ 
                    left: `${((frames.findIndex(f => f.id === selectedFrameId) === -1 ? frames.length - 1 : frames.findIndex(f => f.id === selectedFrameId)) * 104) + 64}px` 
                  }}
                >
                  <div className="absolute top-0 -ml-1.5 w-3 h-3 bg-rose-500 rotate-45" />
                </div>
              </div>
            </div>
          </section>

          {/* Bottom Console Drawer */}
          <div className="h-56 border-t border-zinc-800 flex flex-col bg-zinc-950/80 backdrop-blur-2xl z-20">
            <div className="flex border-b border-zinc-800 px-6 h-12 items-center bg-zinc-900/30">
              <div className="flex gap-4">
                <button 
                  className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest border-b-2 transition-all ${activeTab === 'console' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}
                  onClick={() => setActiveTab('console')}
                >
                  ENGINE_LOGS
                </button>
                <button 
                  className={`px-4 py-2 text-[10px] font-black uppercase tracking-widest border-b-2 transition-all ${activeTab === 'snapshots' ? 'border-indigo-500 text-indigo-400' : 'border-transparent text-zinc-500 hover:text-zinc-300'}`}
                  onClick={() => setActiveTab('snapshots')}
                >
                  CONTEXT_REGISTRY
                </button>
              </div>
              <div className="flex-1" />
              <div className="flex gap-2">
                 <button onClick={() => setLogs([])} className="text-[10px] text-zinc-600 hover:text-zinc-400 flex items-center gap-1 px-2">
                   <Trash2 size={12} /> CLEAR
                 </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 mono">
              {activeTab === 'console' ? (
                <div className="space-y-1.5">
                  {logs.length === 0 && <div className="text-zinc-700 italic text-[11px] font-mono">_ waiting for engine activity...</div>}
                  {logs.map((log) => (
                    <div key={log.id} className="text-[11px] flex gap-4 animate-in slide-in-from-left-2 duration-200">
                      <span className="text-zinc-600 shrink-0">[{log.timestamp.toLocaleTimeString()}]</span>
                      <span className={`font-bold shrink-0 min-w-[70px] ${
                        log.type === 'error' ? 'text-rose-500' : 
                        log.type === 'success' ? 'text-emerald-500' : 
                        log.type === 'command' ? 'text-indigo-400' : 
                        'text-sky-400'
                      }`}>
                        {log.type.toUpperCase()}
                      </span>
                      <span className="text-zinc-400 break-all">{log.message}</span>
                    </div>
                  ))}
                  <div ref={logsEndRef} />
                </div>
              ) : activeTab === 'snapshots' ? (
                <div className="grid grid-cols-4 lg:grid-cols-6 gap-6">
                  {snapshots.length === 0 ? (
                    <div className="col-span-full text-center py-12">
                       <History size={32} className="mx-auto text-zinc-800 mb-2" />
                       <div className="text-zinc-600 italic text-xs uppercase font-bold tracking-widest">No Context Snapshots Found</div>
                    </div>
                  ) : (
                    snapshots.map(snap => (
                      <div key={snap.id} className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 hover:border-indigo-500/50 transition-all cursor-pointer group shadow-xl">
                        <div className="flex justify-between items-start mb-3">
                          <div className="text-[10px] font-bold text-indigo-400 uppercase truncate">{snap.name}</div>
                          <IconButton icon={<Trash2 size={12} />} onClick={() => setSnapshots(s => s.filter(x => x.id !== snap.id))} color="text-zinc-600 hover:text-rose-400" />
                        </div>
                        <div className="flex gap-1 mb-3 overflow-hidden rounded-lg border border-zinc-800">
                          {snap.frames.slice(0, 3).map(f => (
                            <div key={f.id} className="flex-1 aspect-square bg-zinc-800">
                              <img src={f.url} className="w-full h-full object-cover" alt="" />
                            </div>
                          ))}
                        </div>
                        <div className="text-[9px] text-zinc-500 truncate font-mono uppercase tracking-tighter">{snap.prompt}</div>
                      </div>
                    ))
                  )}
                </div>
              ) : (
                <div className="text-zinc-600 italic text-xs font-mono">_ read_only: settings access restricted in dev_mode</div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
