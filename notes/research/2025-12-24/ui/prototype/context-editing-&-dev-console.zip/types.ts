
export enum DriverState {
  IDLE = 'IDLE',
  RUNNING = 'RUNNING',
  PAUSED = 'PAUSED',
  EDITING = 'EDITING'
}

export interface Frame {
  id: string;
  url: string;
  timestamp: number;
  description?: string;
  isAnchor?: boolean;
}

export interface TimelineMarker {
  id: string;
  frameId: string;
  type: 'edit' | 'vlm' | 'snapshot';
  label: string;
  color: string;
}

export interface LogEntry {
  id: string;
  type: 'info' | 'error' | 'success' | 'command';
  message: string;
  timestamp: Date;
}

export interface Snapshot {
  id: string;
  name: string;
  timestamp: Date;
  prompt: string;
  frames: Frame[];
}
