
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Helper to fetch and convert URL to base64 if it's not already a data URL
const getBase64FromUrl = async (url: string): Promise<string> => {
  if (url.startsWith('data:')) {
    return url.split(',')[1];
  }
  const response = await fetch(url);
  const blob = await response.blob();
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
};

export const describeFrame = async (imageUrl: string): Promise<string> => {
  // Always use process.env.API_KEY directly as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Convert URL to base64
  const base64Data = await getBase64FromUrl(imageUrl);
  
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { text: "Describe this video frame accurately for a real-time generation pipeline. Focus on lighting, character expression, and environment." },
        { inlineData: { mimeType: "image/png", data: base64Data } }
      ]
    },
    config: {
      thinkingConfig: { thinkingBudget: 0 }
    }
  });

  return response.text || "No description available.";
};

export const editFrame = async (imageUrl: string, instruction: string): Promise<string> => {
  // Always use process.env.API_KEY directly as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const base64Data = await getBase64FromUrl(imageUrl);
  
  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { inlineData: { mimeType: "image/png", data: base64Data } },
        { text: instruction }
      ]
    }
  });

  // Iterate through parts to find the image part, as per nano banana guidelines
  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("Failed to generate edited image.");
};
